﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication3
{


    public partial class Form4 : Form
    {
        string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\bime.accdb;";
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
   
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\bime.accdb;";
            OleDbConnection con = new OleDbConnection(connectionString);
            OleDbDataAdapter da = new OleDbDataAdapter("Select * From contracts", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            OleDbConnection connect = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\bime.accdb;");


            OleDbDataAdapter da = new OleDbDataAdapter();
            DataTable dt = new DataTable();
            connect.Open();
            da.SelectCommand = new OleDbCommand();
            da.SelectCommand.Connection = connect;
            da.SelectCommand.CommandText = "select * from contracts where contractid=@s";
            da.SelectCommand.Parameters.AddWithValue("@s", textBox8.Text);
            da.Fill(dt);
            connect.Close();
            dataGridView1.DataSource = dt;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OleDbConnection connect = new OleDbConnection( @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\bime.accdb;");

            
            OleDbDataAdapter da = new OleDbDataAdapter();
            
            connect.Open();
            da.DeleteCommand = new OleDbCommand();
            da.DeleteCommand.Connection = connect;
            da.DeleteCommand.CommandText = "delete from contracts where contractid=@s";
            da.DeleteCommand.Parameters.AddWithValue("@s", textBox9.Text);
            da.DeleteCommand.ExecuteNonQuery();
            connect.Close();

            DataTable dt = new DataTable();
            connect.Open();
            da.SelectCommand = new OleDbCommand();
            da.SelectCommand.Connection = connect;
            da.SelectCommand.CommandText = "select * from contracts";
            da.Fill(dt);
            connect.Close();
            dataGridView1.DataSource = dt;
            MessageBox.Show("قرارداد با موفقیت حذف شد");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            OleDbConnection connect = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\bime.accdb;");
            OleDbDataAdapter da = new OleDbDataAdapter();

            connect.Open();
            da.InsertCommand = new OleDbCommand();
            da.InsertCommand.Connection = connect;
            da.InsertCommand.CommandText = "insert into contracts(contractid,customername,nationalid,typeid,insuranceprice,startdate,enddate)" +
                "values(@a,@b,@c,@d,@e,@f,@g)";

            da.InsertCommand.Parameters.AddWithValue("@a", textBox1.Text);
            da.InsertCommand.Parameters.AddWithValue("@b", textBox2.Text);
            da.InsertCommand.Parameters.AddWithValue("@c", textBox3.Text);
            da.InsertCommand.Parameters.AddWithValue("@d", textBox4.Text);
            da.InsertCommand.Parameters.AddWithValue("@e", textBox5.Text);
            da.InsertCommand.Parameters.AddWithValue("@f", textBox6.Text);
            da.InsertCommand.Parameters.AddWithValue("@g", textBox7.Text);
            da.InsertCommand.ExecuteNonQuery();
            connect.Close();

            DataTable dt = new DataTable();
            connect.Open();
            da.SelectCommand = new OleDbCommand();
            da.SelectCommand.Connection = connect;
            da.SelectCommand.CommandText = "select * from contracts";
            da.Fill(dt);
            connect.Close();
            dataGridView1.DataSource = dt;
            MessageBox.Show("قرارداد با موفقیت ثبت شد");




        }
    }
}
